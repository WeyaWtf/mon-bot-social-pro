# mon_bot_social/utils/__init__.py
# This file can be empty. It's used to mark the 'utils' directory as a Python package.

# You could import key utility classes or functions if desired, e.g.:
# from .config_manager import ConfigManager
# from .logger import get_logger

# But generally, keeping it empty is fine.