# mon_bot_social/gui/__init__.py
# This file can be empty. It's used to mark the 'gui' directory as a Python package.