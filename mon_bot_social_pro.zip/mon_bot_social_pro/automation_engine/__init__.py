# mon_bot_social/automation_engine/__init__.py
# This file can be empty. It's used to mark the 'automation_engine' directory as a Python package.

# You could import key classes from submodules if you want them to be
# accessible directly from the automation_engine package, e.g.:
# from .browser_handler import BrowserHandler
# from .element_selectors import ProfilePageLocators # etc.