# mon_bot_social/data_layer/__init__.py
# This file can be empty. It's used to mark the 'data_layer' directory as a Python package.

# You could import database functions here if you wanted to provide a simpler API
# for other modules, e.g.:
# from .database import get_db_connection, initialize_database, record_action

# However, for clarity and to avoid potential circular dependencies if database
# functions were to grow very complex and import from other core modules (unlikely for this layer),
# it's generally fine to keep this __init__.py empty or minimal.